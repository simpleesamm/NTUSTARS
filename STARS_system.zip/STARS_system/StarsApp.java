package STARS_system;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Stars App class
 *
 */
public class StarsApp {
	/**
	 * Student database
	 */
	private static StudentDB studentDB;
	/**
	 * Current date
	 */
	public static Calendar currentDate;
	/**
	 * Course database
	 */
	private static courseDB courseDB;
	/**
	 * Registered courses
	 */
	private static registeredCourses registeredcourses;
	/**
	 * Send email
	 */
	public static sendEmail emailSender;
	/**
	 * Main Method
	 * @throws ClassNotFoundException Class not found Exception handling
	 * @throws IOException Exception handling
	 */
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		init();
		
		start();
		
		
		terminate();
	}
	
	
	
	
	
	
	
	
	/**
	 * Initialize method
	 * @throws ClassNotFoundException Class not found Exception handling
	 * @throws IOException Exception handling
	 */
	public static void init() throws ClassNotFoundException, IOException 
	{
		emailSender = new sendEmail();
		studentDB = new StudentDB();
		registeredcourses = new registeredCourses();
		courseDB = new courseDB();
		currentDate = Calendar.getInstance();
		System.out.println("Welcome to STARS system");
		
	}
	/**
	 * Start method
	 * @throws IOException Exception handling
	 */
	public static void start() throws IOException
	{
		Login login = new Login();
		new actionMenu(login);
	}
	/**
	 * Terminate method
	 */
	public static void terminate()
	{
		studentDB.serializeStudentDB(studentDB.studentDB);
		registeredcourses.serializeRegisterDict(registeredcourses.registerDict);
		courseDB.serializeCourseDB(courseDB.courseDB);
		System.out.println("Exiting..........");
		System.exit(0);
	}
	

}
