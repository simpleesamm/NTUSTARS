package STARS_system;

/**
 * Stores all the department
 *
 */
public enum Department {
	CBE,
	EEE,
	CEE,
	SCSE,
	MSE,
	MAE,
	ADM,
	SSS,
	WKSCI,
	SBS,
	SPMS,
	LKCsoM,
	NIE,
	RSIS,
	ASE,
	HSS,
	NBS
}