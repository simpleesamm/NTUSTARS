package STARS_system;

import java.io.Serializable;
import java.util.Dictionary;

/**
 * Course class
 *
 */
public class Course implements Serializable{
	/**
	 * Course code
	 */
	public  String courseCode;
	/**
	 * Course Name
	 */
	private  String courseName;
	/**
	 * Department of course
	 */
	private Department department;
	/**
	 * Course index
	 */
	public  courseIndex courseIndex[]=new courseIndex[20];
	/**
	 * Index number
	 */
	public  int numIndex=0;
	/**
	 * Course vacancy
	 */
	public  int courseVacancy=0;
	/**
	 * Course constructor
	 * @param courseName - user's given courseName
	 * @param courseCode - user's given courseCode
	 * @param department - user's given department
	 */
	public Course(String courseName,String courseCode,Department department)
	{
		this.courseName = courseName;
		this.courseCode = courseCode;
		this.department = department;
		courseDB.addCourse(courseCode, this);
	}
	/**
	 * Add new index for an existing course method
	 * @param indexID - new indexID
	 */
	public void addIndex(String indexID)
	{
		courseIndex[this.numIndex] = new courseIndex(indexID,this.courseCode);
		this.numIndex++;
		updateVacancy();
	}
	/**
	 * Update vacancy method
	 */
	public void updateVacancy()
	{
		courseVacancy = 0;
		for(int i = 0;i<numIndex;i++)
		{
			courseVacancy = courseVacancy + courseIndex[i].indexVacancy;
		}
	}
	/**
	 * Get index method
	 * @param indexID - existing indexID
	 * @return - courseIndex
	 */
	public courseIndex getIndex(String indexID)
	{
		for(int i=0;i<this.numIndex;i++)
		{
			if (courseIndex[i].indexID.equals(indexID))
			{
				return courseIndex[i];
			}
			
		}
		return null;
	}
	/**
	 * Remove index method
	 * @param indexID - existing indexID
	 * @return - removed or indexID does not exist
	 */
	public boolean removeIndex(String indexID)
	{
		for(int i=0;i<this.numIndex;i++)
		{
			if (courseIndex[i].indexID.equals(indexID))
			{
				for(int j=i;j<this.numIndex-1;j++)
				{
					System.out.println(courseIndex[j].indexID);
					System.out.println(courseIndex[j+1].indexID);
					courseIndex[j]=courseIndex[j+1];

				}
				this.numIndex--;
				updateVacancy();
				courseDB.addCourse(courseCode, this);
				return true;
			}
		}
		System.out.println("No such Index!");
		return false;
	}
	/**
	 * Print Indexes of course method
	 */
	public void printIndexes()
	{	
		if (this.numIndex!=0)
		{
			System.out.println("Course Has Indexes:");
			
			for(int i=0;i<this.numIndex;i++)
		{
			System.out.println(courseIndex[i].indexID);
		}}
		else {
			System.out.println("There are no indexes yet!");
		}
		
	}
	/**
	 * Get department method
	 * @return department
	 */
	public Department getDepartment()
	{
		return this.department;
	}
	/**
	 * Get course name method
	 * @return courseName
	 */
	public String getCourseName()
	{
		return this.courseName;
	}
	
	
	
}
